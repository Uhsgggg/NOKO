#include "SceneSerializer.h"

#include "ThirdParty/nlohmann/json.hpp"

#include "Engine/Scene/GameObject.h"
#include "Engine/Camera/CameraPlay.h"

#include "Game/Objects/GameObjectFactory.h"
#include "Game/Objects/PrimitiveObject.h"
#include "Game/Objects/FbxObject.h"

#include "Game/Components/ComponentRegistry.h"

#include <fstream>
#include <stdexcept>
#include <utility>

using json = nlohmann::json;
using namespace std;
using namespace DirectX;

namespace
{
	// JSON�z�񂩂�float3��ǂݍ���
	// �@ReadFloat3() ��Position�ERotation�EScale�̂悤��
	// �@�R��float�l��ǂݍ��ނ��߂̋��ʊ֐�
	void ReadFloat3(
		const json& data,
		float values[3],
		const char* fieldName)
	{
		if (!data.is_array() || data.size() != 3)
		{
			// JSON�̓��e���s���������ꍇ�ɗ�O�𔭐�������
			throw runtime_error(
				string(fieldName) +
				" must be an array of 3 numbers."
			);
		}

		for (int i = 0; i < 3; i++)
		{
			values[i] = data.at(i).get<float>();
		}
	}

	void ReadFloat4(
		const json& data,
		float values[4],
		const char* fieldName)
	{
		if (!data.is_array() || data.size() != 4)
		{
			throw runtime_error(
				string(fieldName) +
				" must be an array of 4 numbers."
			);
		}

		for (int i = 0; i < 4; i++)
		{
			values[i] = data.at(i).get<float>();

			// �F�͈̔͂��m�F
			if (!(values[i] >= 0.0f && values[i] <= 1.0f))
			{
				throw runtime_error(
					string(fieldName) +
					" values must be between 0 and 1."
				);
			}
		}
	}
}

//========================================
// JSON�ۑ�����
//========================================
bool SceneSerializer::Save(
	const string& filePath, 
	const vector<unique_ptr<GameObject>>& objects, 
	const CameraPlay& playCamera, string& error)
{
	error.clear();

	try
	{
		// JSON�S�̂��쐬
		json root;

		// �ۑ��`���̃o�[�W����
		root["version"] = 1;

		// GameObject�ꗗ
		root["objects"] = json::array();

		for (const auto& pObject : objects)
		{
			if (!pObject) continue;

			json objectData;

			//========================================
			// GameObject�̎��
			//========================================
			// GameObjectFactory�����ޖ����擾
			string type =
				GameObjectFactory::GetTypeName(*pObject);

			// ���Ή��̎�ނȂ�ۑ����Ȃ�
			if (type.empty())
			{
				throw runtime_error(
					"Unsupported GameObject type."
				);
			}

			objectData["type"] = type;

			//========================================
			// PrimitiveObject�̌`���ۑ�
			//========================================
			const PrimitiveObject* pPrimitive =
				dynamic_cast<const PrimitiveObject*>(pObject.get());

			if (pPrimitive)
			{
				string shapeName;

				switch (pPrimitive->GetShape())
				{
				case PrimitiveShape::Box:
					shapeName = "Box";
					break;

				case PrimitiveShape::Cylinder:
					shapeName = "Cylinder";
					break;

				case PrimitiveShape::Sphere:
					shapeName = "Sphere";
					break;

				default:
					throw runtime_error(
						"Unknown PrimitiveShape."
					);
				}

				objectData["shape"] = shapeName;
			}

			//========================================
			// FBX�̃��f���p�X��ۑ�
			//========================================
			const FbxObject* pFbx =
				dynamic_cast<const FbxObject*>(pObject.get());

			if (pFbx)
			{
				objectData["modelPath"] = 
					pFbx->GetModelPath();
			}

			//========================================
			// �I�u�W�F�N�g��
			//========================================
			objectData["name"] = pObject->GetName();

			//========================================
			// GameObject�̐F��JSON�֕ۑ�
			//========================================
			// ���݂̐F���擾
			const XMFLOAT4& color = pObject->GetColor();

			// RGBA��4�̒l��z��Ƃ��ĕۑ�
			objectData["color"] = {
				color.x,
				color.y,
				color.z,
				color.w,
			};

			//========================================
			// Transform
			//========================================
			const Transform& t = pObject->GetTransform();

			objectData["transform"] = {
					{
						"position",
					{
						t.position[0],
						t.position[1],
						t.position[2]
					}
					},
				{
					"rotation",
					{
						t.rotation[0],
						t.rotation[1],
						t.rotation[2]
					}
				},
				{
					"scale",
					{
						t.scale[0],
						t.scale[1],
						t.scale[2]
					}
				}
			};

			//========================================
			// Components
			//========================================
			objectData["components"] = json::array();

			for (const auto& pComponent : pObject->GetComponents())
			{
				if (!pComponent) continue;

				// �R���|�[�l���g��ID����o�^����T��
				const ComponentRegistry::Entry* pEntry =
					ComponentRegistry::Find(
						pComponent->GetTypeId()
						);

				if (!pEntry)
				{
					throw runtime_error(
						"Unregistered Component: " +
						string(pComponent->GetTypeId())
					);
				}

				json componentData;

				// ���ʏ���ۑ�
				componentData["type"] = pEntry->typeId;
				componentData["enabled"] = pComponent->IsEnabled();

				// ��ނ��Ƃ̃p�����[�^��ۑ�
				pEntry->save(*pComponent, componentData);

				// �z��ɒǉ�
				objectData["components"].push_back(componentData);
			}
		}

		//========================================
		// Play�J�����̏���ۑ�
		//========================================
		const auto& cameraPos = playCamera.GetPosition();
		const auto& cameraLook = playCamera.GetLook();

		root["playCamera"] = {
				{
					"position",
				{
					cameraPos.x,
					cameraPos.y,
					cameraPos.z
				}
				},
			{
				"look",
				{
					cameraLook.x,
					cameraLook.y,
					cameraLook.z
				}
			}
		};

		//========================================
		// JSON���t�@�C���֏�������
		//========================================
		// �ǂ݂₷���悤�ɃC���f���g4�ŕϊ�
		string text = root.dump(4);

		ofstream file(
			filePath,
			ios::binary | ios::trunc
		);

		if (!file.is_open())
		{
			throw runtime_error(
				"Cannot open file for writing: " +
				filePath
			);
		}

		file.write(
			text.data(),
			static_cast<streamsize>(text.size())
		);

		file.flush();

		if (!file)
		{
			throw runtime_error(
				"Failed to write stage file."
			);
		}

		return true;
	}
	catch (const std::exception& e)
	{
		error = e.what();
		return false;
	}
}




//========================================
// JSON�ǂݍ��ݏ���
//========================================
bool SceneSerializer::Load(
	const string& filePath,
	vector<unique_ptr<GameObject>>& objects,
	CameraPlay& playCamera,
	string& error)
{
	error.clear();

	try
	{
		//========================================
		// JSON�t�@�C�����J��
		//========================================
		ifstream file(
			filePath,
			ios::binary
		);

		if (!file.is_open())
		{
			throw runtime_error(
				"Cannot open stage file: " +
				filePath
			);
		}

		// JSON�Ƃ��ēǂݍ���
		json root = json::parse(file);

		// �ۑ��`�����m�F
		int version = root.at("version").get<int>();

		if (version != 1)
		{
			throw runtime_error(
				"Unsupported stage version."
			);
		}

		const json& savedObjects = root.at("objects");

		if (!savedObjects.is_array())
		{
			throw runtime_error(
				"objects must be an array."
			);
		}

		// ��������ꎞ�I�ɍ��
		vector<unique_ptr<GameObject>> loadedObjects;

		//========================================
		// GameObject�𕜌�����
		//========================================
		for (const auto& objectData : savedObjects)
		{
			string type = objectData.at("type").get<string>();

			// JSON�ɋL�^���ꂽ��ނ��琶��
			unique_ptr<GameObject> pObject =
				GameObjectFactory::Create(type);

			// ���Ή��̎�ނȂ�ǂݍ��ݎ��s
			if (!pObject)
			{
				throw runtime_error(
					"Unknown GameObject type:" + type
				);
			}

			//========================================
			// FBX�̃��f���p�X�𕜌�
			//========================================
			FbxObject* pFbx =
				dynamic_cast<FbxObject*>(pObject.get());

			if (pFbx)
			{
				string modelPath =
					objectData.at("modelPath").get<string>();

				if (!pFbx->SetModelPath(modelPath))
				{
					throw runtime_error(
						"Failed to load FBX: " + modelPath
					);
				}
			}

			//========================================
			// PrimitiveObject�̌`��𕜌�
			//========================================
			PrimitiveObject* pPrimitive =
				dynamic_cast<PrimitiveObject*>(pObject.get());

			if (pPrimitive)
			{
				// shape���Ȃ��ꍇ��Box�������l�ɂ���
				string shapeName = "Box";

				if (objectData.contains("shape"))
				{
					shapeName =
						objectData.at("shape").get<string>();
				}

				if (shapeName == "Box")
				{
					pPrimitive->SetShape(PrimitiveShape::Box);
				}
				else if (shapeName == "Cylinder")
				{
					pPrimitive->SetShape(PrimitiveShape::Cylinder);
				}
				else if (shapeName == "Sphere")
				{
					pPrimitive->SetShape(PrimitiveShape::Sphere);
				}
				else
				{
					throw runtime_error(
						"Unknown PrimitiveShape: " + shapeName
					);
				}
			}

			//========================================
			// ���O�𕜌�
			//========================================
			string name = objectData.at("name").get<string>();

			if (name.empty())
			{
				throw runtime_error(
					"GameObject name is empty"
				);
			}

			// JSON����ǂݎ�������O�𔽉f
			pObject->SetName(name);

			// ���O�̏d��������
			for (const auto& pExisting : loadedObjects)
			{
				if (pExisting->GetName() == name)
				{
					throw runtime_error(
						"Duplicate GameObject name."
					);
				}
			}

			//========================================
			// GameObject�̐F�𕜌�
			//========================================
			// �����l�͔�
			XMFLOAT4 color(1.0f, 1.0f, 1.0f, 1.0f);

			// JSON�ɐF��񂪂���ꍇ�����ǂݍ���
			if (objectData.contains("color"))
			{
				float values[4] = {};

				ReadFloat4(
					objectData.at("color"),
					values,
					"color"
				);

				color = XMFLOAT4(
					values[0],
					values[1],
					values[2],
					values[3]
				);
			}

			// �ǂݎ�����F��GameObject�֔��f
			pObject->SetColor(color);

			//========================================
			// Transform�𕜌�
			//========================================
			const json& savedTransform = objectData.at("transform");

			Transform& t = pObject->GetTransform();

			ReadFloat3(
				savedTransform.at("position"),
				t.position,
				"position"
			);

			ReadFloat3(
				savedTransform.at("rotation"),
				t.rotation,
				"rotation"
			);

			ReadFloat3(
				savedTransform.at("scale"),
				t.scale,
				"scale"
			);

			//========================================
			// Components�𕜌�
			//========================================
			// �E�����R���|�[�l���g�����Ă����ꍇ�����Ă���
			// �@�@�ǂݍ��񂾍ۂɁA�����R���|�[�l���g�ƌ�t���R���|�[�l���g��
			// �@�@�����������ꍇ�G���[���o�邽��
			pObject->ClearComponents();

			const json& savedComponents = objectData.at("components");

			if (!savedComponents.is_array())
			{
				throw runtime_error(
					"components must be an array."
				);
			}

			for (const auto& componentData : savedComponents)
			{
				// �ۑ�����Ă����ނ��擾
				string componentType =
					componentData.at("type").get<string>();

				// �o�^�ς݂�Component���m�F
				const ComponentRegistry::Entry* pEntry =
					ComponentRegistry::Find(componentData);

				if (!pEntry)
				{
					throw runtime_error(
						"Unknown Component type: " +
						componentData
					);
				}

				// �o�^����Ă��鐶���֐����Ă�
				unique_ptr<Component> pComponent =
					pEntry->create(pObject.get());

				if (!pComponent)
				{
					throw runtime_error(
						"Component creation failed."
					);
				}

				// ��ނ��Ƃ̐ݒ�𕜌�
				pEntry->load(
					*pComponent,
					componentData
				);

				// �L���E�����𕜌�
				pComponent->SetEnabled(
					componentData.at("enabled").get<bool>()
				);

				// GameObject�֒ǉ�
				if (!pObject->AddComponent(move(pComponent)))
				{
					throw runtime_error(
						"Duplicate Component."
					);
				}
			}

			// �����������W��������Ԃɂ���
			pObject->SaveInitialTransform();

			loadedObjects.push_back(move(pObject));
		}

		//========================================
		// Play�J�����̏���ǂݍ���
		//========================================
		XMFLOAT3 cameraPos = playCamera.GetPosition();
		XMFLOAT3 cameraLook = playCamera.GetLook();

		if (root.contains("playCamera"))
		{
			const json& cameraData = root.at("playCamera");

			float pos[3];
			float look[3];

			ReadFloat3(
				cameraData.at("position"),
				pos,
				"playCamera.position"
			);

			ReadFloat3(
				cameraData.at("look"),
				look,
				"playCamera.look"
			);

			float dx = look[0] - pos[0];
			float dz = look[2] - pos[2];

			if (!(dx * dx + dz * dz > 0.0001f))
			{
				throw runtime_error(
					"Invaild Play Camera direction."
				);
			}

			cameraPos = XMFLOAT3(
				pos[0],
				pos[1],
				pos[2]
			);

			cameraLook = XMFLOAT3(
				look[0],
				look[1],
				look[2]
			);
		}

		//========================================
		// �ǂݍ��݂��S�Đ������������ւ���
		//========================================
		objects.swap(loadedObjects);

		//========================================
		// Play�J�����̈ʒu������
		//========================================
		playCamera.SetPose(
			cameraPos,
			cameraLook
		);

		return true;
	}
	catch (const exception& e)
	{
		error = e.what();
		return false;
	}
}