#include "GameObjectFactory.h"

#include "Engine/Scene/GameObject.h"
#include "Game/Objects/Ground.h"
#include "Game/Objects/Goal.h"
#include "Game/Objects/PrimitiveObject.h"
#include "Game/Objects/FbxObject.h"

#include <memory>

using namespace std;
using namespace DirectX;

unique_ptr<GameObject> GameObjectFactory::Create(
	const string& type)
{
	// Ground�𐶐�
	if (type == "Ground")
	{
		return unique_ptr<GameObject>(new Ground());
	}

	// Goal�𐶐�
	if (type == "Goal")
	{
		return unique_ptr<GameObject>(new Goal());
	}

	// ��{�}�`�𐶐�
	if (type == "Primitive")
	{
		return unique_ptr<GameObject>(new PrimitiveObject());
	}

	// FBX���f���𐶐�
	if (type == "Fbx")
	{
		return unique_ptr<GameObject>(new FbxObject());
	}

	// ���Ή��̎��
	return nullptr;
}

string GameObjectFactory::GetTypeName(
	const GameObject& object)
{
	// Ground���擾
	if (dynamic_cast<const Ground*>(&object))
	{
		return "Ground";
	}

	// Goal���擾
	if (dynamic_cast<const Goal*>(&object))
	{
		return "Goal";
	}

	// Primitive���擾
	if (dynamic_cast<const PrimitiveObject*>(&object))
	{
		return "Primitive";
	}

	// Fbx���擾
	if (dynamic_cast<const FbxObject*>(&object))
	{
		return "Fbx";
	}

	// ���Ή��̎��
	return "";
}

#ifdef _DEBUG
unique_ptr<GameObject> GameObjectFactory::CreateForEditor(
	const string& type)
{
	// �܂���{��ԂŐ���
	unique_ptr<GameObject> pObject = Create(type);

	if (!pObject) return nullptr;

	Transform& transform = pObject->GetTransform();

	if (type == "Ground")
	{
		transform.position[0] = 1.0f;

		transform.scale[0] = 1.00f;
		transform.scale[1] = 0.01f;
		transform.scale[2] = 1.00f;
	}
	else if (type == "Goal")
	{
		transform.position[0] = 1.0f;
		transform.position[1] = 1.0f;

		transform.scale[0] = 0.5f;
		transform.scale[1] = 0.5f;
		transform.scale[2] = 0.5f;
	}
	else if (type == "Primitive")
	{
		transform.position[0] = 0.0f;
		transform.position[1] = 1.0f;
		transform.position[2] = 0.0f;

		transform.scale[0] = 1.0f;
		transform.scale[1] = 1.0f;
		transform.scale[2] = 1.0f;
	}

	return pObject;
}
#endif