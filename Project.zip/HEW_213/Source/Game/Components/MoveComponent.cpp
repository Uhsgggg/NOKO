#include "MoveComponent.h"
#include "Engine/Scene/GameObject.h"

#ifdef _DEBUG
#include "imgui.h"
#endif

using namespace std;

//========================================
// �R���X�g���N�^
//========================================
MoveComponent::MoveComponent(
	GameObject* pOwner,
	float x, float y, float z)
	: Component(pOwner)
	, m_velocity{ x, y, z }
{
}

//========================================
// �ړ�����
//========================================
void MoveComponent::Update(float deltaTime)
{
	if (!m_pOwner) return;

	// ���L�҂�Transform���擾
	Transform& transform = m_pOwner->GetTransform();

	// ���x �~ �o�ߎ��Ԃ����ړ�
	transform.position[0] += m_velocity[0] * deltaTime;
	transform.position[1] += m_velocity[1] * deltaTime;
	transform.position[2] += m_velocity[2] * deltaTime;
}

//========================================
// �R���|�[�l���g�𕡐�
//========================================
unique_ptr<Component> MoveComponent::Clone(
	GameObject* pNewOwner) const
{
	unique_ptr<Component> pCopy(
		new MoveComponent(
			pNewOwner,
			m_velocity[0],
			m_velocity[1],
			m_velocity[2]
		)
	);

	// �L���E�����������p��
	pCopy->SetEnabled(IsEnabled());

	return pCopy;
}

//========================================
// �ړ����x��ύX
//========================================
void MoveComponent::SetVelocity(float x, float y, float z)
{
	m_velocity[0] = x;
	m_velocity[1] = y;
	m_velocity[2] = z;
}

#ifdef _DEBUG
//========================================
// Inspector�̕\��
//========================================
void MoveComponent::DrawDebugInspector()
{
	using namespace ImGui;
	DragFloat3(
		"Velocity",
		m_velocity,
		0.05f
	);

	TextDisabled("Units / second");
}
#endif


