#include "CameraDebug.h"
#include <iostream>
#include <algorithm>
#include <cmath>

#include "Engine/Debug/DebugEditor.h"

using namespace DirectX;
using namespace std;

CameraDebug::CameraDebug()
    : m_yaw(0.0f)
    , m_pitch(-atan2f(3.5f, 5.0f))
    , m_moveSpeed(5.0f)
    , m_fastMultiplier(3.0f)
    , m_mouseSensitivity(0.003f)
    , m_previousMousePos{}
    , m_wasRightDown(false)
{

}

CameraDebug::~CameraDebug()
{

}

// �X�V����
void CameraDebug::Update()
{
    //========================================
    // ImGui���L�[�{�[�h���g�p���Ȃ�
    // �J�����̑�����󂯕t���Ȃ�
    //========================================
    if (DebugEditor::WantsKeyboard())
    {
        // �}�E�X�ɂ���]��Ԃ���������
        m_wasRightDown = false;
        return;
    }

    // �����ʒu�ɖ߂�
    if (IsKeyTrigger('R'))
    {
        Reset();
        return;
    }

    UpdateRotation();
    UpdateMovement();
    UpdateLook();
}

// �}�E�X�ɂ�鎋�_��] 
void CameraDebug::UpdateRotation()
{
    bool uiMouse = DebugEditor::WantsMouse();

    // �}�E�X�ɂ���]
    POINT currentMousePos{};

    // �E�N���b�N�̏��
    bool rightDown =
        !uiMouse && (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;

    if (GetCursorPos(&currentMousePos))
    {
        // �E�N���b�N�������Ă���Ԃ�����]
        if (rightDown && m_wasRightDown)
        {
            LONG deltaX =
                currentMousePos.x - m_previousMousePos.x;

            LONG deltaY =
                currentMousePos.y - m_previousMousePos.y;

            m_yaw += deltaX * m_mouseSensitivity;
            m_pitch -= deltaY * m_mouseSensitivity;
        }

        // �}�E�X�̏�Ԃ�ۑ�
        m_previousMousePos = currentMousePos;
        m_wasRightDown = rightDown;
    }
    else
    {
        m_wasRightDown = false;
    }

    // ���L�[�ɂ���]
    constexpr float rotationSpeed = XMConvertToRadians(90.0f) / FPS;

    if (IsKeyPress(VK_LEFT))  m_yaw   -= rotationSpeed;
    if (IsKeyPress(VK_RIGHT)) m_yaw   += rotationSpeed;
    if (IsKeyPress(VK_UP))    m_pitch += rotationSpeed;
    if (IsKeyPress(VK_DOWN))  m_pitch -= rotationSpeed;

    // �^��E�^���������Ȃ��悤�ɐ���
    constexpr float maxPitch = XMConvertToRadians(89.0f);

    if (m_pitch > maxPitch)  m_pitch = maxPitch;
    else if (m_pitch < -maxPitch) m_pitch = -maxPitch;
}

// �L�[�{�[�h�ɂ��ړ�
void CameraDebug::UpdateMovement()
{
    if (DebugEditor::WantsKeyboard()) return;

    // 60FPS
    constexpr float deltaTime = 1.0f / FPS;
    float speed = m_moveSpeed * deltaTime;

    if (IsKeyPress(VK_SHIFT))
    {
        speed *= m_fastMultiplier;
    }

    // �O�i����
    XMFLOAT3 forward =
    {
        sinf(m_yaw) * cosf(m_pitch),
        sinf(m_pitch),
        cosf(m_yaw) * cosf(m_pitch)
    };

    // ���������̉E�x�N�g��
    XMFLOAT3 right =
    {
        cosf(m_yaw),
        0.0f,
        -sinf(m_yaw)
    };

    XMVECTOR direction = XMVectorZero();

    XMVECTOR vForward = XMLoadFloat3(&forward);
    XMVECTOR vRight = XMLoadFloat3(&right);

    if (IsKeyPress('W')) direction += vForward;
    if (IsKeyPress('S')) direction -= vForward;
    if (IsKeyPress('D')) direction += vRight;
    if (IsKeyPress('A')) direction -= vRight;

    if (IsKeyPress(VK_SPACE))
    {
        direction += XMVectorSet(0, 1, 0, 0);
    }
    if (IsKeyPress(VK_CONTROL))
    {
        direction -= XMVectorSet(0, 1, 0, 0);
    }

    // �΂߈ړ��������Ȃ�Ȃ��悤�ɂ���
    if (XMVectorGetX(XMVector3LengthSq(direction)) > 0.0f)
    {
        direction = XMVector3Normalize(direction);
        direction *= speed;

        XMVECTOR position = XMLoadFloat3(&m_pos);
        position += direction;

        XMStoreFloat3(&m_pos, position);
    }
}

// �����_���X�V
void CameraDebug::UpdateLook()
{
    XMFLOAT3 forward =
    {
        sinf(m_yaw) * cosf(m_pitch),
        sinf(m_pitch),
        cosf(m_yaw) * cosf(m_pitch)
    };

    m_look.x = m_pos.x + forward.x;
    m_look.y = m_pos.y + forward.y;
    m_look.z = m_pos.z + forward.z;
}

// �����ʒu�֖߂�
void CameraDebug::Reset()
{
    m_pos = { 0.0f, 3.5f, -5.0f };
    m_yaw = 0.0f;
    m_pitch = -atan2f(3.5f, 5.0f);
    m_wasRightDown = false;
    UpdateLook();
}