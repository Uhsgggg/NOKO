#include "ModelManager.h"
#include "StaticFbxModel.h"

using namespace std;

//========================================
// ModelManager�̎擾
//========================================
ModelManager& ModelManager::GetInstance()
{
	static ModelManager instance;
	return instance;
}

//========================================
// FBX���f���̓ǂݍ���
//========================================
shared_ptr<StaticFbxModel> ModelManager::Load(const string& filePath)
{
	if (filePath.empty())
	{
		return nullptr;
	}

	//========================================
	// �ǂݍ��ݍς݂��m�F
	//========================================
	auto it = m_models.find(filePath);

	if (it != m_models.end())
	{
		shared_ptr<StaticFbxModel> pExisting =
			it->second.lock();

		if (pExisting)
		{
			return pExisting;
		}
	}

	//========================================
	// �V�������f�����쐬
	//========================================
	shared_ptr<StaticFbxModel> pModel(new StaticFbxModel());

	//========================================
	// FBX��ǂݍ���
	//========================================
	if (!pModel->Load(filePath.c_str()))
	{
		return nullptr;
	}

	//========================================
	// �ǂݍ��ݍς݃��f���Ƃ��ċL�^
	//========================================
	m_models[filePath] = pModel;

	return pModel;
}







